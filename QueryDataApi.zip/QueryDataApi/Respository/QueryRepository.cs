﻿using QueryDataApi.Dal;
using QueryDataApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QueryDataApi.Respository
{
    public class QueryRepository : IQueryRepository
    {
        QueryContextDal _queryContextDal;

        public QueryRepository(QueryContextDal queryContextDal)
        {
            _queryContextDal = queryContextDal;
        }

        public async Task<int> AddQuery(QueryModel query)
        {
            var lastQueryId = _queryContextDal.Quries.LastOrDefault().Id;
            query.Id = lastQueryId + 1;

            try
            {
                await _queryContextDal.Quries.AddAsync(query);
                await _queryContextDal.SaveChangesAsync();
                return query.Id;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }     

        public async Task<int> DeleteQuery(long queryId)
        {
            var existingStudent = _queryContextDal.Quries.FirstOrDefault(s => s.Id == queryId);
            if (existingStudent == null)
            {
                return 0;
            }

            _queryContextDal.Quries.Remove(existingStudent);
            var result = await _queryContextDal.SaveChangesAsync();
            return result;
        }

        public Task<List<QueryModel>> GetQueries()
        {
            var queries = _queryContextDal.Quries;
            if (queries == null)
            {
                return null;
            }
            return Task.FromResult(queries.ToList());
        }

        public Task<QueryModel> GetQueryById(long queryId)
        {
            var query = _queryContextDal.Quries.FirstOrDefault(x => x.Id == queryId);
            if (query == null)
            {
                return null;
            }
            return Task.FromResult(query);
        }

        public async Task<int> UpdateQuery(long queryId, QueryModel query)
        {
            var existingStudent = _queryContextDal.Quries.FirstOrDefault(s => s.Id == queryId);
            if (existingStudent == null)
            {
                return 0;
            }

            existingStudent.Status = query.Status;
            try
            {
                _queryContextDal.Quries.Update(existingStudent);
                var res = await _queryContextDal.SaveChangesAsync();
                return res;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
