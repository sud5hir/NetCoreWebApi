﻿using QueryDataApi.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace QueryDataApi.Respository
{
    public interface IQueryRepository
    {
        Task<List<QueryModel>> GetQueries();

        Task<QueryModel> GetQueryById(long queryId);

        Task<int> AddQuery(QueryModel post);

        Task<int> DeleteQuery(long postId);

        Task<int> UpdateQuery(long id, QueryModel post);
    }
}
