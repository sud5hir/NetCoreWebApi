﻿namespace QueryDataApi.Model
{
    public class Queries
    {
        public QueryModel[] QueryList { get; set; }
    }
}
